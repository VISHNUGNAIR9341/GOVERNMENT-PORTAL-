import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Schemes from './pages/Schemes';
import Applications from './pages/Applications';
import News from './pages/News';
import Layout from './components/Layout';

function App() {
  return (
    <>
      <div className="indian-gradient" />
      <Router>
        <Toaster position="top-right" />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/schemes" element={<Schemes />} />
            <Route path="/applications" element={<Applications />} />
            <Route path="/news" element={<News />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;