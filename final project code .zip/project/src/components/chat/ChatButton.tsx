import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ChatBox } from './ChatBox';

export function ChatButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button
        variant="outline"
        onClick={() => setIsOpen(true)}
        className="flex items-center"
      >
        <MessageSquare className="mr-2 h-4 w-4" />
        Chat with AI Assistant
      </Button>
      {isOpen && <ChatBox onClose={() => setIsOpen(false)} />}
    </>
  );
}