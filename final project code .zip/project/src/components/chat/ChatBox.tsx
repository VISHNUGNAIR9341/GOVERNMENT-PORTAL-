import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChatMessage } from './ChatMessage';
import { openai } from '@/lib/openai';
import { INITIAL_MESSAGE, SYSTEM_PROMPT } from '@/lib/chat-prompts';
import { getFallbackResponse } from '@/lib/chat-utils';

interface Message {
  text: string;
  isBot: boolean;
}

interface ChatBoxProps {
  onClose: () => void;
}

export function ChatBox({ onClose }: ChatBoxProps) {
  const [messages, setMessages] = useState<Message[]>([
    { text: INITIAL_MESSAGE, isBot: true }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [usesFallback, setUsesFallback] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { text: userMessage, isBot: false }]);
    setIsLoading(true);

    try {
      let botResponse: string;
      
      if (!usesFallback) {
        try {
          const completion = await openai.chat.completions.create({
            messages: [
              { role: 'system', content: SYSTEM_PROMPT },
              ...messages.map(msg => ({
                role: msg.isBot ? 'assistant' : 'user',
                content: msg.text
              })),
              { role: 'user', content: userMessage }
            ],
            model: 'gpt-3.5-turbo',
            temperature: 0.7,
            max_tokens: 500,
          });
          
          botResponse = completion.choices[0]?.message?.content || getFallbackResponse(userMessage);
        } catch (error) {
          console.warn('Switching to fallback mode due to API error:', error);
          setUsesFallback(true);
          botResponse = getFallbackResponse(userMessage);
        }
      } else {
        botResponse = getFallbackResponse(userMessage);
      }

      setMessages(prev => [...prev, { text: botResponse, isBot: true }]);
    } catch (error) {
      console.error('ChatBot Error:', error);
      const errorResponse = "I apologize, but I'm having trouble processing your request. " +
        "Please try asking about specific schemes or document requirements, " +
        "or visit myscheme.gov.in for more information.";
      setMessages(prev => [...prev, { text: errorResponse, isBot: true }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-white rounded-lg shadow-xl flex flex-col max-h-[600px]">
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="text-lg font-semibold">Government Schemes Assistant</h3>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <ChatMessage key={index} message={message.text} isBot={message.isBot} />
        ))}
        {isLoading && (
          <div className="flex items-center justify-center py-2">
            <div className="ashoka-chakra"></div>
          </div>
        )}
      </div>

      <form onSubmit={handleSend} className="p-4 border-t flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about government schemes..."
          disabled={isLoading}
        />
        <Button type="submit" disabled={isLoading}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}