import React from 'react';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  message: string;
  isBot?: boolean;
}

export function ChatMessage({ message, isBot }: ChatMessageProps) {
  return (
    <div className={`flex gap-3 ${isBot ? 'bg-gray-50' : ''} p-4`}>
      {isBot ? (
        <Bot className="h-6 w-6 text-blue-600" />
      ) : (
        <User className="h-6 w-6 text-gray-600" />
      )}
      <p className="text-sm text-gray-900">{message}</p>
    </div>
  );
}