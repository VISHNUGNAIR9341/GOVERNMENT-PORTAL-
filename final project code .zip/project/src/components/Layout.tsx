import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  User, 
  FileText, 
  ClipboardList, 
  Newspaper,
  LogOut 
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Profile', href: '/profile', icon: User },
  { name: 'Schemes', href: '/schemes', icon: FileText },
  { name: 'Applications', href: '/applications', icon: ClipboardList },
  { name: 'News', href: '/news', icon: Newspaper },
];

export default function Layout() {
  const location = useLocation();

  return (
    <div className="min-h-screen">
      <div className="flex h-screen">
        <div className="hidden md:flex md:flex-shrink-0">
          <div className="flex flex-col w-64">
            <div className="flex flex-col flex-grow pt-5 bg-white/80 backdrop-blur-sm border-r">
              <div className="flex flex-col flex-grow px-4">
                <nav className="flex-1 space-y-1">
                  {navigation.map((item) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.name}
                        to={item.href}
                        className={`${
                          location.pathname === item.href
                            ? 'bg-blue-50/80 text-blue-600'
                            : 'text-gray-600 hover:bg-gray-50/80'
                        } group flex items-center px-2 py-2 text-sm font-medium rounded-md backdrop-blur-sm`}
                      >
                        <Icon className="mr-3 h-6 w-6" />
                        {item.name}
                      </Link>
                    );
                  })}
                </nav>
                <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
                  <button className="w-full flex items-center px-2 py-2 text-sm font-medium text-red-600 rounded-md hover:bg-red-50/80 backdrop-blur-sm">
                    <LogOut className="mr-3 h-6 w-6" />
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col flex-1 overflow-hidden">
          <main className="flex-1 relative overflow-y-auto focus:outline-none">
            <div className="py-6">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                <div className="bg-white/80 backdrop-blur-sm p-6 rounded-lg shadow-lg">
                  <Outlet />
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}