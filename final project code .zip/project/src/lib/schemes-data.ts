export const SCHEMES_INFO = {
  'PM Kisan': {
    eligibility: 'All landholding farmers\' families',
    benefits: '₹6,000 per year in three installments',
    documents: ['Aadhaar Card', 'Land Records', 'Bank Account Details'],
  },
  'Ayushman Bharat': {
    eligibility: 'Poor and vulnerable families',
    benefits: 'Health coverage up to ₹5 lakhs per family per year',
    documents: ['Aadhaar Card', 'Ration Card', 'Income Certificate'],
  },
  'PM Awas Yojana': {
    eligibility: 'Economically weaker sections, low-income groups',
    benefits: 'Financial assistance for house construction',
    documents: ['Aadhaar Card', 'Income Certificate', 'Land Documents'],
  },
} as const;

export const COMMON_RESPONSES = {
  greeting: "Hello! I'm here to help you with government schemes. What would you like to know?",
  error: "I'm currently experiencing technical difficulties. Here are some helpful resources:\n\n" +
    "1. Visit myscheme.gov.in for scheme details\n" +
    "2. Call toll-free: 1800-111-111\n" +
    "3. Visit your nearest Common Service Centre",
  documents: "Common documents required for most schemes:\n" +
    "- Aadhaar Card\n" +
    "- Income Certificate\n" +
    "- Caste Certificate (if applicable)\n" +
    "- Bank Account Details",
  process: "General application process:\n" +
    "1. Fill out the application form\n" +
    "2. Submit required documents\n" +
    "3. Verify details at local office\n" +
    "4. Track application status online",
};