import OpenAI from 'openai';

export const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});