import { SCHEMES_INFO, COMMON_RESPONSES } from './schemes-data';

export function getFallbackResponse(query: string): string {
  const normalizedQuery = query.toLowerCase();
  
  // Check for greetings
  if (normalizedQuery.match(/^(hi|hello|hey|greetings)/)) {
    return COMMON_RESPONSES.greeting;
  }

  // Check for document-related queries
  if (normalizedQuery.includes('document') || normalizedQuery.includes('papers')) {
    return COMMON_RESPONSES.documents;
  }

  // Check for process-related queries
  if (normalizedQuery.includes('how to') || normalizedQuery.includes('process')) {
    return COMMON_RESPONSES.process;
  }

  // Check for specific scheme queries
  for (const [scheme, info] of Object.entries(SCHEMES_INFO)) {
    if (normalizedQuery.includes(scheme.toLowerCase())) {
      return `${scheme}:\n\n` +
        `Eligibility: ${info.eligibility}\n` +
        `Benefits: ${info.benefits}\n` +
        `Required Documents: ${info.documents.join(', ')}`;
    }
  }

  // Default response
  return "I can help you with:\n" +
    "1. Information about specific schemes\n" +
    "2. Document requirements\n" +
    "3. Application processes\n" +
    "Please ask about any of these topics!";
}