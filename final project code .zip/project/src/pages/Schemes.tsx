import React from 'react';
import { FileText, Users, IndianRupee } from 'lucide-react';

const schemes = [
  {
    id: 1,
    name: "PM Kisan Samman Nidhi",
    description: "Direct income support of ₹6,000 per year to farmer families",
    eligibility: "All landholding farmer families",
    benefits: "₹6,000 per year in three installments of ₹2,000 each",
    documents: ["Aadhaar Card", "Land Records", "Bank Account Details"],
    deadline: "Ongoing",
    category: "Agriculture"
  },
  {
    id: 2,
    name: "Ayushman Bharat",
    description: "Comprehensive healthcare coverage for eligible families",
    eligibility: "Poor and vulnerable families as per SECC database",
    benefits: "Health coverage up to ₹5 lakhs per family per year",
    documents: ["Aadhaar Card", "Ration Card", "Income Certificate"],
    deadline: "Ongoing",
    category: "Healthcare"
  },
  {
    id: 3,
    name: "PM Awas Yojana",
    description: "Housing for all by providing financial assistance for house construction",
    eligibility: "EWS/LIG households with annual income up to ₹3 lakhs",
    benefits: "Financial assistance up to ₹2.67 lakhs per house",
    documents: ["Aadhaar Card", "Income Certificate", "Land Documents"],
    deadline: "March 31, 2024",
    category: "Housing"
  }
];

export default function Schemes() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">Available Schemes</h1>
      <div className="space-y-6">
        {schemes.map((scheme) => (
          <div key={scheme.id} className="bg-white/50 backdrop-blur-sm shadow-lg rounded-lg overflow-hidden">
            <div className="p-6">
              <div className="flex items-center mb-4">
                <FileText className="h-6 w-6 text-blue-600 mr-2" />
                <h3 className="text-xl font-semibold text-gray-900">{scheme.name}</h3>
              </div>
              
              <p className="text-gray-600 mb-4">{scheme.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <Users className="h-4 w-4 mr-1" />
                    Eligibility
                  </h4>
                  <p className="text-gray-600">{scheme.eligibility}</p>
                </div>
                
                <div>
                  <h4 className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <IndianRupee className="h-4 w-4 mr-1" />
                    Benefits
                  </h4>
                  <p className="text-gray-600">{scheme.benefits}</p>
                </div>
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Required Documents</h4>
                <ul className="list-disc list-inside text-gray-600">
                  {scheme.documents.map((doc, index) => (
                    <li key={index}>{doc}</li>
                  ))}
                </ul>
              </div>
              
              <div className="mt-4 flex justify-between items-center">
                <span className="text-sm text-blue-600 font-medium">
                  Category: {scheme.category}
                </span>
                <span className="text-sm text-gray-500">
                  Deadline: {scheme.deadline}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}