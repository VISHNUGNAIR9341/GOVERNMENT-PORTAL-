import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Profile() {
  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">Profile Details</h1>
      
      <form className="space-y-6 bg-white shadow sm:rounded-lg p-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
          <Input id="name" type="text" placeholder="Enter your full name" className="mt-1" />
        </div>

        <div>
          <label htmlFor="age" className="block text-sm font-medium text-gray-700">Age</label>
          <Input id="age" type="number" placeholder="Enter your age" className="mt-1" />
        </div>

        <div>
          <label htmlFor="gender" className="block text-sm font-medium text-gray-700">Gender</label>
          <select
            id="gender"
            className="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          >
            <option value="">Select gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div>
          <label htmlFor="caste" className="block text-sm font-medium text-gray-700">Caste</label>
          <select
            id="caste"
            className="mt-1 block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          >
            <option value="">Select caste</option>
            <option value="general">General</option>
            <option value="obc">OBC</option>
            <option value="sc">SC</option>
            <option value="st">ST</option>
          </select>
        </div>

        <div>
          <label htmlFor="income" className="block text-sm font-medium text-gray-700">Yearly Income</label>
          <Input id="income" type="number" placeholder="Enter yearly income" className="mt-1" />
        </div>

        <Button type="submit" className="w-full">Save Profile</Button>
      </form>
    </div>
  );
}