import React from 'react';

export default function Applications() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">My Applications</h1>
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <div className="px-4 py-5 sm:p-6">
          <p className="text-gray-500">No applications submitted yet.</p>
        </div>
      </div>
    </div>
  );
}