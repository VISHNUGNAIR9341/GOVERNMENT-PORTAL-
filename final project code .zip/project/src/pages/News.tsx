import React from 'react';
import { Bell } from 'lucide-react';

const newsItems = [
  {
    id: 1,
    title: "PM Kisan: 15th Installment Released",
    date: "2024-03-15",
    description: "₹2,000 credited to farmer accounts under PM-KISAN scheme. Check your bank account for the latest installment.",
    category: "Scheme Update"
  },
  {
    id: 2,
    title: "Ayushman Bharat Coverage Expanded",
    date: "2024-03-10",
    description: "New medical procedures added under Ayushman Bharat coverage. Beneficiaries can now avail advanced treatments.",
    category: "Healthcare"
  },
  {
    id: 3,
    title: "Digital India Skills Program Launched",
    date: "2024-03-05",
    description: "New initiative for youth skill development in digital technologies. Registration opens next week.",
    category: "Education"
  }
];

export default function News() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900 mb-6">News & Updates</h1>
      <div className="space-y-4">
        {newsItems.map((item) => (
          <div key={item.id} className="bg-white/50 backdrop-blur-sm shadow rounded-lg overflow-hidden">
            <div className="p-6">
              <div className="flex items-center">
                <Bell className="h-5 w-5 text-blue-600 mr-2" />
                <span className="text-sm text-blue-600 font-medium">{item.category}</span>
              </div>
              <h3 className="mt-2 text-xl font-semibold text-gray-900">{item.title}</h3>
              <p className="mt-1 text-gray-600">{item.description}</p>
              <div className="mt-4 text-sm text-gray-500">
                {new Date(item.date).toLocaleDateString('en-IN', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}